# ans.fhir.fr.modele#0.1.0: ANS IG Example(en)

## Pages

* [Accueil](index.md)
* [EX actor - JSON Representation](ActorDefinition-ex-actor.json.md)
* [Specifications](specifications.md)
* [Annexes](annexes.md)
* [Informations sur la traduction](translationinfo.md)
* [Sécurité](annexe-securite.md)
* [](ActorDefinition-ex-actor.change.history.md)
* [Tests](tests.md)
* [EX actor](ActorDefinition-ex-actor.md)
* [EX actor](ActorDefinition-ex-actor-testing.md)
* [Artifacts Summary](artifacts.md)
* [Synthèse](spe-synthese.md)
* [EX actor](ActorDefinition-ex-actor.ai.md)
* [Historique des versions](change-log.md)
* [Processus collaboratif 1](spe-processus-collab-1.md)
* [EX actor - XML Representation](ActorDefinition-ex-actor.xml.md)
* [Téléchargements et usages](annexe-downloads.md)
* [EX actor - TTL Representation](ActorDefinition-ex-actor.ttl.md)

## Resources

### CodeSystems

* [Compétences CodeSystem](CodeSystem-competence-code-system.md)
* [Type de carte](CodeSystem-type-carte-code-system.md)

### ValueSets

* [EyeColor Value Set](ValueSet-EyeColorVS.md)
* [Melting Pot Value Set](ValueSet-MeltingPotVS.md)
* [ModifiedAdministrativeGender](ValueSet-ModifiedAdministrativeGender.md)
* [Type Carte Value Set](ValueSet-TypeCarteVS.md)

### Logicals

* [EX Concept Metier](StructureDefinition-EXConceptMetier.md)
* [EX Contact](StructureDefinition-EXContact.md)

### Resource Profiles

* [Patient français](StructureDefinition-fr-patient.md)

### Extensions

* [EyeColor](StructureDefinition-EyeColor.md)

### Basics

* [ex-actor](Basic-ex-actor.md)

### CapabilityStatements

* [Nom du Capability statement](CapabilityStatement-nom-du-capability-statement.md)

### ImplementationGuides

* [ANS IG Example](ImplementationGuide-ans.fhir.fr.modele.md)

### Examples

* [frpatient-exemple (Patient)](Patient-frpatient-exemple.md)
