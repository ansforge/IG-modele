# ans.fhir.fr.modele#0.1.0: ANS IG Example(fr)

## Pages

* [Accueil](index.md)
* [Specifications](specifications.md)
* [Annexes](annexes.md)
* [Informations sur la traduction](translationinfo.md)
* [Sécurité](annexe-securite.md)
* [](ActorDefinition-EX-Actor.change.history.md)
* [EX Actor](ActorDefinition-EX-Actor.ai.md)
* [Tests](tests.md)
* [EX Actor - XML Representation](ActorDefinition-EX-Actor.xml.md)
* [EX Actor - JSON Representation](ActorDefinition-EX-Actor.json.md)
* [Résumé des artefacts](artifacts.md)
* [Synthèse](spe-synthese.md)
* [Historique des versions](change-log.md)
* [EX Actor](ActorDefinition-EX-Actor.md)
* [Processus collaboratif 1](spe-processus-collab-1.md)
* [Téléchargements et usages](annexe-downloads.md)
* [EX Actor - TTL Representation](ActorDefinition-EX-Actor.ttl.md)
* [EX Actor](ActorDefinition-EX-Actor-testing.md)

## Resources

### CodeSystems

* [Compétences CodeSystem](CodeSystem-competence-code-system.md)
* [Type de carte](CodeSystem-type-carte-code-system.md)

### ValueSets

* [EyeColor Value Set](ValueSet-EyeColorVS.md)
* [Melting Pot Value Set](ValueSet-MeltingPotVS.md)
* [ModifiedAdministrativeGender](ValueSet-ModifiedAdministrativeGender.md)
* [Type Carte Value Set](ValueSet-TypeCarteVS.md)

### Logicals

* [EX Contact](StructureDefinition-EXContact.md)

### Resource Profiles

* [Patient français](StructureDefinition-fr-patient.md)

### Extensions

* [EyeColor](StructureDefinition-EyeColor.md)

### Basics

* [EX-Actor](Basic-EX-Actor.md)

### CapabilityStatements

* [Nom du Capability statement](CapabilityStatement-nom-du-capability-statement.md)

### ImplementationGuides

* [ANS IG Example](ImplementationGuide-ans.fhir.fr.modele.md)

### Examples

* [frpatient-exemple (Patient)](Patient-frpatient-exemple.md)
