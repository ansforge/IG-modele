# ans.fhir.fr.[code]#0.1.0: ANS IG Example

## Pages

* [Accueil](index.md)
* [Flux d'alimentation](spec-technique-flux-alimentation.md)
* [Vue d'ensemble](spec-fonctionnelle-intro.md)
* [Flux de consommation](spec-technique-flux-consommation.md)
* [Alimentation](spec-fonctionnelle-alimentation.md)
* [Introduction](spec-technique-intro.md)
* [Historique des versions](change-log.md)
* [Artifacts Summary](artifacts.md)
* [Sécurité](annexe-securite.md)
* [Autres Ressources](autres_ressources.md)
* [Téléchargements et usages](annexe-downloads.md)
* [Vue d'ensemble](spec-technique-vue-ensemble.md)

## Resources

### CodeSystems

* [Compétences CodeSystem](CodeSystem-competence-code-system.md)
* [Type de carte](CodeSystem-type-carte-code-system.md)

### ValueSets

* [EyeColor Value Set](ValueSet-EyeColorVS.md)
* [Melting Pot Value Set](ValueSet-MeltingPotVS.md)
* [ModifiedAdministrativeGender](ValueSet-ModifiedAdministrativeGender.md)
* [Type Carte Value Set](ValueSet-TypeCarteVS.md)

### Resource Profiles

* [Patient français](StructureDefinition-fr-patient.md)

### Extensions

* [EyeColor](StructureDefinition-EyeColor.md)

### ImplementationGuides

* [ANS IG Example](index.md)

### Examples

* [frpatient-exemple (Patient)](Patient-frpatient-exemple.md)
